# Stockport-Predictive-Sentiment-Analysis


Stock market analyzer and predictor using Elasticsearch, Twitter, News headlines and Python natural language processing and sentiment analysis
